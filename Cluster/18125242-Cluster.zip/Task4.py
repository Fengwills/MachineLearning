from sklearn.mixture import GaussianMixture
from sklearn.metrics import adjusted_rand_score
from sklearn.datasets import load_iris
from sklearn.preprocessing import Normalizer
from sklearn.model_selection import cross_val_predict
iris = load_iris()
iris_data = iris.data
# Normalizer().fit_transform(iris_data)
iris_target = iris.target
model = GaussianMixture(n_components = 3)
model.fit(iris_data)
predictions = model.predict(iris_data)
ari = adjusted_rand_score(iris_target,predictions)
print(ari)
#0.9038742317748124x